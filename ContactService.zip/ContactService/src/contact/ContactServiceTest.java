package contact;



import static org.junit.jupiter.api.Assertions.*;



import org.junit.jupiter.api.BeforeEach;

import org.junit.jupiter.api.Test;



class ContactServiceTest {



    private ContactService service;

    private Contact contact;



    @BeforeEach

    void setUp() {

        service = new ContactService();

        contact = new Contact(

                "1001",

                "Bryan",

                "Salmeron",

                "4795551234",

                "123 Main Street");

    }



    @Test

    void testAddContact() {

        service.addContact(contact);



        assertEquals(contact, service.getContact("1001"));

    }



    @Test

    void testAddDuplicateContactId() {

        service.addContact(contact);



        Contact duplicate = new Contact(

                "1001",

                "John",

                "Smith",

                "4795555678",

                "456 Oak Street");



        assertThrows(IllegalArgumentException.class, () -> {

            service.addContact(duplicate);

        });

    }



    @Test

    void testAddNullContact() {

        assertThrows(IllegalArgumentException.class, () -> {

            service.addContact(null);

        });

    }



    @Test

    void testDeleteContact() {

        service.addContact(contact);

        service.deleteContact("1001");



        assertNull(service.getContact("1001"));

    }



    @Test

    void testDeleteContactThatDoesNotExist() {

        assertThrows(IllegalArgumentException.class, () -> {

            service.deleteContact("9999");

        });

    }



    @Test

    void testUpdateContact() {

        service.addContact(contact);



        service.updateContact(

                "1001",

                "John",

                "Smith",

                "4795555678",

                "456 Oak Street");



        Contact updatedContact = service.getContact("1001");



        assertEquals("John", updatedContact.getFirstName());

        assertEquals("Smith", updatedContact.getLastName());

        assertEquals("4795555678", updatedContact.getPhone());

        assertEquals("456 Oak Street", updatedContact.getAddress());

        assertEquals("1001", updatedContact.getContactId());

    }



    @Test

    void testUpdateContactThatDoesNotExist() {

        assertThrows(IllegalArgumentException.class, () -> {

            service.updateContact(

                    "9999",

                    "John",

                    "Smith",

                    "4795555678",

                    "456 Oak Street");

        });

    }



    @Test

    void testUpdateWithInvalidPhone() {

        service.addContact(contact);



        assertThrows(IllegalArgumentException.class, () -> {

            service.updateContact(

                    "1001",

                    "John",

                    "Smith",

                    "12345",

                    "456 Oak Street");

        });

    }

}
