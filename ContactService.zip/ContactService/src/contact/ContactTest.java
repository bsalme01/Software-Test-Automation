package contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ContactTest {

    @Test
    void testContactCreation() {
        Contact contact = new Contact(
                "1001",
                "Bryan",
                "Salmeron",
                "4795551234",
                "123 Main Street");

        assertEquals("1001", contact.getContactId());
        assertEquals("Bryan", contact.getFirstName());
        assertEquals("Salmeron", contact.getLastName());
        assertEquals("4795551234", contact.getPhone());
        assertEquals("123 Main Street", contact.getAddress());
    }

    @Test
    void testContactIdTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(
                    "12345678901",
                    "Bryan",
                    "Salmeron",
                    "4795551234",
                    "123 Main Street");
        });
    }

    @Test
    void testContactIdNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(
                    null,
                    "Bryan",
                    "Salmeron",
                    "4795551234",
                    "123 Main Street");
        });
    }

    @Test
    void testFirstNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(
                    "1001",
                    "BryanBryan1",
                    "Salmeron",
                    "4795551234",
                    "123 Main Street");
        });
    }

    @Test
    void testFirstNameNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(
                    "1001",
                    null,
                    "Salmeron",
                    "4795551234",
                    "123 Main Street");
        });
    }

    @Test
    void testLastNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(
                    "1001",
                    "Bryan",
                    "SalmeronABC",
                    "4795551234",
                    "123 Main Street");
        });
    }

    @Test
    void testLastNameNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(
                    "1001",
                    "Bryan",
                    null,
                    "4795551234",
                    "123 Main Street");
        });
    }

    @Test
    void testPhoneTooShort() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(
                    "1001",
                    "Bryan",
                    "Salmeron",
                    "479555123",
                    "123 Main Street");
        });
    }

    @Test
    void testPhoneContainsLetters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(
                    "1001",
                    "Bryan",
                    "Salmeron",
                    "47955A1234",
                    "123 Main Street");
        });
    }

    @Test
    void testPhoneNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(
                    "1001",
                    "Bryan",
                    "Salmeron",
                    null,
                    "123 Main Street");
        });
    }

    @Test
    void testAddressTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(
                    "1001",
                    "Bryan",
                    "Salmeron",
                    "4795551234",
                    "1234567890123456789012345678901");
        });
    }

    @Test
    void testAddressNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(
                    "1001",
                    "Bryan",
                    "Salmeron",
                    "4795551234",
                    null);
        });
    }

    @Test
    void testUpdateContactFields() {
        Contact contact = new Contact(
                "1001",
                "Bryan",
                "Salmeron",
                "4795551234",
                "123 Main Street");

        contact.setFirstName("John");
        contact.setLastName("Smith");
        contact.setPhone("4795555678");
        contact.setAddress("456 Oak Street");

        assertEquals("John", contact.getFirstName());
        assertEquals("Smith", contact.getLastName());
        assertEquals("4795555678", contact.getPhone());
        assertEquals("456 Oak Street", contact.getAddress());
    }
}
